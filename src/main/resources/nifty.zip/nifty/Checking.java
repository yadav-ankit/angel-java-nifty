package com.nifty;

import java.text.ParseException;

public class Checking {

    public static void main(String[] args) throws ParseException {
    String date = "29MAR2023";

    String s = "NIFTY30DEC2717000PE";

        System.out.println(s);
    }
}
