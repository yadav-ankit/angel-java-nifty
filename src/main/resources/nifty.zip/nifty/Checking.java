package com.nifty;

public class Checking {

    public static void main(String[] args) {
        String strike = "1665000.000000";

        System.out.println();
    }
}
