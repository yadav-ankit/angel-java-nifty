package com.nifty;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Checking {

    public static void main(String[] args) throws ParseException {
    String date = "29MAR2023";

        System.out.println(formatToUTCTime(date));
    }

    private static String formatToUTCTime(String timeStamp) throws ParseException {
        SimpleDateFormat dateParser = new SimpleDateFormat("ddMMMyyyy");
        SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
        Date date = dateParser.parse(timeStamp);

        return dateFormatter.format(date);
    }
}
